#!/bin/bash
rm *.pyc 2>/dev/null
rm *~ 2>/dev/null
rm parser.out 2>/dev/null
rm parsetab.py
